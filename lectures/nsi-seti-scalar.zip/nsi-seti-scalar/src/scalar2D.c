/* ---------------- */
/* --- matrix.c --- */
/* ---------------- */

#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

#include "def.h"
#include "nrutil.h"

#include "mymacro.h"
#include "x86intrin.h" // si compilateur Intel

/* ----------------------------------------------------- */
void avgk_f32matrix(float32 **X, int n, int k, float32 **Y)
/* ----------------------------------------------------- */
{
    // A COMPLETER
}
/* ---------------------------------------------- */
void avg3_f32matrix(float32 **X, int n, float32 **Y)
/* ---------------------------------------------- */
{
    // A COMPLETER
}
/* ---------------------------------------------- */
void avg5_f32matrix(float32 **X, int n, float32 **Y)
/* ---------------------------------------------- */
{
    // A COMPLETER
}
/* ----------------------------------------------------- */
void maxk_f32matrix(float32 **X, int n, int k, float32 **Y)
/* ----------------------------------------------------- */
{
    // A COMPLETER
}
/* ---------------------------------------------- */
void max3_f32matrix(float32 **X, int n, float32 **Y)
/* ---------------------------------------------- */
{
    // A COMPLETER
}
/* ---------------------------------------------- */
void max5_f32matrix(float32 **X, int n, float32 **Y)
/* ---------------------------------------------- */
{
    // A COMPLETER
}
// ------------------
void test_avg2D(void)
// ------------------
{
    int n;
    int b = 2;
    float32 **X, **Y3, **Y5;
    
    char *format = "%6.2f ";
    
    int iter, niter = 2;
    int run, nrun = 5;
    double t0, t1, dt, tmin, t;
    double cycles;

    // ------------------------- //
    // -- calculs des indices -- //
    // ------------------------- //
    
    DEBUG(n=5);
    
    BENCH(n=100);
    //BENCH(n=128);
    //BENCH(n=256);
    //BENCH(n=512);
    //BENCH(n=1024);
    //BENCH(n=1000);
    
    printf("n = %d\n", n);
    
    // ------------------- //
    // -- allocation 2D -- //
    // ------------------- //
    
    X  = f32matrix(0-b, n-1+b, 0-b, n-1+b);
    Y3 = f32matrix(0, n-1, 0, n-1);
    Y5 = f32matrix(0, n-1, 0, n-1);
    
    // ---------- //
    // -- init -- //
    // ---------- //
    
    zero_f32matrix(X, 0-b, n-1+b, 0-b, n-1+b);
    zero_f32matrix(Y3, 0, n-1, 0, n-1);
    zero_f32matrix(Y5, 0, n-1, 0, n-1);
    
    set_f32matrix_param(X, 0, n-1, 0, n-1,  1, 1,  1);    
 
    // -------------------- //
    // -- affichage init -- //
    // -------------------- //
 
    DEBUG(display_f32matrix(X,  0, n-1, 0, n-1, format, "X"));
      
    CHRONO(avgk_f32matrix(X, n, 3, Y3),cycles); printf("avgk=3 "); DEBUG(display_f32matrix(Y3, 0, n-1, 0, n-1, format, "Y3 ")); BENCH(printf(format, cycles/(n*n*n))); puts(""); zero_f32matrix(Y3, 0, n-1, 0, n-1);
    CHRONO(avgk_f32matrix(X, n, 5, Y5),cycles); printf("avgk=5 "); DEBUG(display_f32matrix(Y5, 0, n-1, 0, n-1, format, "Y5 ")); BENCH(printf(format, cycles/(n*n*n))); puts(""); zero_f32matrix(Y5, 0, n-1, 0, n-1);
    CHRONO(avg3_f32matrix(X, n, Y3),cycles);    printf("avg3 ");   DEBUG(display_f32matrix(Y3, 0, n-1, 0, n-1, format, "Y3 ")); BENCH(printf(format, cycles/(n*n*n))); puts(""); zero_f32matrix(Y3, 0, n-1, 0, n-1);
    CHRONO(avg5_f32matrix(X, n, Y5),cycles);    printf("avg5 ");   DEBUG(display_f32matrix(Y5, 0, n-1, 0, n-1, format, "Y5 ")); BENCH(printf(format, cycles/(n*n*n))); puts(""); zero_f32matrix(Y5, 0, n-1, 0, n-1);
    
    // ---------- //
    // -- free -- //
    // ---------- //
    
    free_f32matrix(X, 0-b, n-1+b, 0-b, n-1+b);
    free_f32matrix(Y3, 0, n-1, 0, n-1);
    free_f32matrix(Y5, 0, n-1, 0, n-1);
}
/* ==================================== */
void main_scalar2D(int argc, char * argv[])
/* ==================================== */
{
    test_avg2D();
    //test_max2D();
}
