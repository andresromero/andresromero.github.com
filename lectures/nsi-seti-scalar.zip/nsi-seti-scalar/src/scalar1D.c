/* ---------------- */
/* --- vector.c --- */
/* ---------------- */

#include <stdio.h>
#include <stdlib.h>

#include "def.h"
#include "nrutil.h"

#include "vdef.h"
#include "vnrutil.h"

#include "mutil.h"
#include "mymacro.h"

#include "x86intrin.h" // si compilateur Intel

/* --------------------------------------------------- */
void avgk_f32vector(float32 *X, int n, int k, float32 *Y)
/* --------------------------------------------------- */
{
    // A COMPLETER
}
/* -------------------------------------------- */
void avg3_f32vector(float32 *X, int n, float32 *Y)
/* -------------------------------------------- */
{
    // A COMPLETER
}
/* -------------------------------------------- */
void avg5_f32vector(float32 *X, int n, float32 *Y)
/* -------------------------------------------- */
{
    // A COMPLETER
}
/* ========================== */
/* === Fonctions de tests === */
/* ========================== */

// ------------------
void test_avg1D(void)
// ------------------
{
    int n;
    int b; // bord
    int j0, j1;
    int j0b, j1b;
    
    float32 *X, *Y3, *Y5;
         
    char *format     = "%6.2f";
    
    int iter, niter = 4;
    int run, nrun = 5;
    double t0, t1, dt, tmin, t;
    double cycles;

    puts("--------------------------");
    puts("-- test_add_dot_vector ---");
    puts("--------------------------");
    
    // ------------------------- //
    // -- calculs des indices -- //
    // ------------------------- //
    
    DEBUG(n=4);
    
    // exemples de taille de donnees pour analyser l'impact du cache
    //BENCH(n=10*10);
    //BENCH(n=100*100);
    BENCH(n=1000*1000);
    //BENCH(n=1000*10000);

    printf("n = %d\n", n);
    
    b = 2; // pour les calculs avec bords
    j0  = 0;   j1  = n-1;   // vecteur sans bord
    j0b = 0-b; j1b = n-1+b; // vecteur avec bords
    
    // -------------------------------- //
    // -- allocation des tableaux 1D -- //
    // -------------------------------- //
        
    X   = f32vector(j0b, j1b);
    Y3  = f32vector(j0,  j1);
    Y5  = f32vector(j0,  j1);

    
    // ---------- //
    // -- init -- //
    // ---------- //
    
    zero_f32vector(X, j0b, j1b);
    zero_f32vector(Y3, j0, j1);
    zero_f32vector(Y5, j0, j1);
    
    set_f32vector_param(X, j0, j1, 1, 1);
    
    // -------------------- //
    // -- affichage init -- //
    // -------------------- //
    
    DEBUG(display_f32vector(X, j0, j1, format, "X"));
    
    // ------------ //
    // -- calcul -- //
    // ------------ //
    
    CHRONO(avgk_f32vector(X, n, 3, Y3),cycles); printf("avgk=3 "); DEBUG(display_f32vector(Y3, j0, j1, format, "Y3")); BENCH(printf(format, cycles/n)); BENCH(puts(""));
    CHRONO(avgk_f32vector(X, n, 5, Y5),cycles); printf("avgk=5 "); DEBUG(display_f32vector(Y5, j0, j1, format, "Y5")); BENCH(printf(format, cycles/n)); BENCH(puts(""));
    CHRONO(avg3_f32vector(X, n,    Y3),cycles); printf("avg3 ");   DEBUG(display_f32vector(Y3, j0, j1, format, "Y3")); BENCH(printf(format, cycles/n)); BENCH(puts(""));
    CHRONO(avg5_f32vector(X, n,    Y5),cycles); printf("avg5 ");   DEBUG(display_f32vector(Y5, j0, j1, format, "Y5")); BENCH(printf(format, cycles/n)); BENCH(puts(""));

    // ---------- //
    // -- free -- //
    // ---------- //   
    
    free_f32vector(X, j0b, j1b);
    free_f32vector(Y3, j0, j1);
    free_f32vector(Y5, j0, j1);
    
}
/* ================================= */
int main_scalar1D(int argc, char *argv[])
/* ================================= */
{
    test_avg1D(); // a remplir 
    //test_max1D(); // a creer

    return 0;
}
