/* -------------- */
/* --- main.c --- */
/* -------------- */

#include <stdio.h>

#include "def.h"
#include "nrutil.h"

#include "vdef.h"
#include "vnrutil.h"

#include "mutil.h"

#include "scalar1D.h"
#include "scalar2D.h"

#include "mymacro.h"
void info()
{
#ifdef ENABLE_BENCHMARK
    puts("mode Benchmark ON");
    puts("DEBUG OFF");
#else
    puts("mode Benchmark OFF");
    puts("DEBUG ON");
#endif
}
int main(int argc, char *argv[])
{
    info();
    main_scalar1D(argc, argv);
    main_scalar2D(argc, argv);
    return 0;   
}