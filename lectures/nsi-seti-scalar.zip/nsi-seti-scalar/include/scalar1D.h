/* ------------------ */
/* --- scalar1D.h --- */
/* ------------------ */

#ifndef __SCALAR_1D_H__
#define __SCALAR_1D_H__

#ifdef __cplusplus
#pragma message ("C++")
extern "C" {
#endif  

void main_scalar1D(int argc, char *argv[]);

#ifdef __cplusplus
}
#endif

#endif /* __SCALAR_2D_H__ */
