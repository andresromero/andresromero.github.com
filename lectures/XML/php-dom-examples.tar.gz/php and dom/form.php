<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
	<form action="action.php" method="post">
	<p>Votre nom : <input type="text" name="nom" /></p>
	<p>Votre âge : <input type="text" name="age" /></p>
	<p><input type="submit" value="OK"></p>
	</form>
</body>
</html>