<!-- Compter le nobre de livres écrits par un auteur avec XPath-->
<?php
$author = 'Jack Herrington';

$doc = new DOMDocument();
$doc->load('books.xml');

$xpath = new DOMXPath($doc);
$query = "//book[author='$author']";
$result = $xpath->query($query);
$nbooks = 0;
foreach ($result as $element) {
	$nbooks++;
}
echo "$nbooks";
?>