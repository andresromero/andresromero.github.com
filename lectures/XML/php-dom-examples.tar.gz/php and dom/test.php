<html>
<body>
<?php
	$i = 1;
	if(1==$i){
		echo "i est 1 <br>";
	}else{
		echo "i n'est pas 1 <br>";
	};

	while($i < 5)
	{
		// switch ($i) {
		// 	case 1:
		// 		# code...
		// 		break;
		// 	case 2:
		// 		# code...
		// 		break;
		// 	case 3:
		// 		echo "$i, i est soi 1 2 soit 3 <br>";
		// 		break;
		// 	case 4:
		// 		echo "$i, i est 4";
		// 		break;
			
		// 	default:
		// 		echo "$i, 0 > i > 4";
		// 		break;
		// };

		echo "i est $i<br>";
		$i += 1;	
	}

	do
	{ 
		echo "i is $i<br>";
		$i--;
	}while ($i > 0);
	
	echo (0==$i ? "i est a nouveu 0" : "i n’est pas 0");

	
?>
</body>
</html>