<!-- Compter le nobre de livres écrits par un auteur sans XPath-->
<?php
$doc = new DOMDocument();
$doc->load('books.xml');

$author = 'Jack Herrington';
$total = 0;
$elements = $doc->getElementsByTagName("author");
foreach ($elements as $element) {
	if($element->nodeValue==$author)
	{
		$total++;
	}
}
echo "Auteur $author a ecrit $total livres en total<br>";
?>