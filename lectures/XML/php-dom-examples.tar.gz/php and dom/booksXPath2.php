<!-- Compter le nobre de livres écrits par un auteur avec XPath V2-->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
	<?php
		$author = 'Jack Herrington';

		$doc = new DOMDocument();
		$doc->load('books.xml');

		$xpath = new DOMXPath($doc);
		$query = "count(//book[author='$author'])";
		$nbooks = $xpath->evaluate($query);

		echo "L'auteur $author a écrit $nbooks en total.<br>";
	?>
</body>
</html>
