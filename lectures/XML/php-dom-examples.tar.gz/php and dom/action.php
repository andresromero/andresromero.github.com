<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
	Bonjour,
	<?php
		 echo htmlspecialchars($_POST['nom']);
	?>.
	Tu as 
	<?php echo (int)$_POST['age']+2; ?>
	ans.
</body>
</html>
