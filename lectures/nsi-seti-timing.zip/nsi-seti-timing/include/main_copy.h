// ------------------- //
// --- main_copy.h --- //
// ------------------- //

#ifndef __MAIN_COPY_H__
#define __MAIN_COPY_H__

#ifdef __cplusplus
extern "C" {
#endif
    
int main_copy(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif // __MAIN_COPY_H__
