// ---------------- //
// --- dcycle.h --- //
// ---------------- //

#ifndef __DCYCLE_H__
#define __DCYCLE_H__

#ifdef __cplusplus
extern "C" {
#endif
    
double dcycle(); // chrono en cycle

#ifdef __cplusplus
}
#endif

#endif // __DCYCLE_H__
