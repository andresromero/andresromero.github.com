// ----------------------------- //
// --- main_multiplication.h --- //
// ----------------------------- //

#ifndef __MAIN_MULTIPLICATION_H__
#define __MAIN_MULTIPLICATION_H__

#ifdef __cplusplus
extern "C" {
#endif
    
int main_multiplication(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif // __MAIN_MULTIPLICATION_H__
