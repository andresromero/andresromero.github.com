// --------------------- //
// --- main_timing.h --- //
// --------------------- //

#ifndef __MAIN_TIMING_H__
#define __MAIN_TIMING_H__

#ifdef __cplusplus
extern "C" {
#endif
    
#define LOOP 4

#ifdef __cplusplus
}
#endif

#endif // __MAIN_TIMING_H__
