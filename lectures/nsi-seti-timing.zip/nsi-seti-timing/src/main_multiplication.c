// ----------------------------- //
// --- main_multiplication.c --- //
// ----------------------------- //

// Copyright (c) Daniel Etiemble, LRI, Univ Paris-Sud www.lri.fr/~de
// Copyright (c)  Lionel Lacassagne, LRI, Univ Paris-Sud www.lri.fr/~lacas

#include <stdio.h>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <mmintrin.h>

#include "def.h" // typage fort des types de base du C
#include "nrutil.h" // allocation
#include "dcycle.h" // chrono
#include "main_timing.h" // LOOP

int min (int a,int b)
{if (a<b) return a;
else return b; 
}

// ---------------------------------------------
void validate_F(float32 **c, float32 **r, int n)
// ---------------------------------------------
{
    int i,j;
    for ( i = 0; i < n; i++) {
        for ( j = 0; j < n; j++) {
            if (c[i][j] != r[i][j]) {	
                printf("c != rc at [%d][%d]\n",i,j);
            }
        }
    }
}
// -------------------------------------------
void validate_I(sint32 **c, sint32 **r, int n)
// -------------------------------------------
{
    int i,j;
    for ( i = 0; i < n; i++) {
        for ( j = 0; j < n; j++) {
            if (c[i][j] != r[i][j]) {	
                printf("c != rc at [%d][%d]\n",i,j);
            }
        }
    }
}
// --------------------------------------------
void main_PS_F(float32 *BF, float32 *CF, int n)
// --------------------------------------------
{
	int i, j, k, m;
    float32 SF;
    double begin, benchtime;
    
	for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_PS_F %d  %8.3f \n",n, (double) benchtime/n);
    }
    printf ("\n");
}
// ------------------------------------------
void main_PS_I(sint32 *BI, sint32 *CI, int n)
// ------------------------------------------
{
    int i, j, k, m;
    sint32 SI;
    double begin, benchtime;
    
    for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_PS_I %d  %8.3f \n",n, (double) benchtime/n);
    }
    printf ("\n");
}
// ----------------------------------------------------------------        
void main_MM_ijk_F(float32 **AF, float32 **XF, float32 **YF, int n)
// ----------------------------------------------------------------
{
    int i, j, k, m;
    float32 SF;
    double begin, benchtime;
    
    for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_ijk_F %d  %8.3f \n",n, (double) benchtime/(n*n*n));
    }
    printf ("\n");
}

// -------------------------------------------------------------
void main_MM_ijk_I(sint32 **AI, sint32 **XI, sint32 **YI, int n)
// -------------------------------------------------------------
{
    int i, j, k, m;
    sint32 SI;
    double begin, benchtime;
    
    for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_ijk_I %d  %8.3f \n",n, (double) benchtime/(n*n*n));
    }
    printf ("\n");
}
// ----------------------------------------------------------------
void main_MM_ikj_F(float32 **AF, float32 **XF, float32 **YF, int n)
// ----------------------------------------------------------------  
{
    int i, j, k, m;
    float32 SF;
    double begin, benchtime;
    
    for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_ikj_F %d  %8.3f \n",n, (double) benchtime/(n*n*n));
    }
    printf ("\n");
}
// --------------------------------------------------------
main_MM_ikj_I(sint32 **AI, sint32 **XI, sint32 **YI, int n)
// --------------------------------------------------------
{
    int i, j, k, m;
    sint32 SI;
    double begin, benchtime;
    
    for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_ikj_I %d  %8.3f \n",n, (double) benchtime/(n*n*n));
    }
    printf ("\n");
}
// ----------------------------------------------------------------------------
void main_MM_bijk_F(float32 **AF, float32 **XF, float32 **YF, int n, int bsize)
// ----------------------------------------------------------------------------
{
    int i, j, jj, k, kk, m;
    float32 SF;
    double begin, benchtime;
    
    for (m=0;m<LOOP;m++)
    {
        begin=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime = dcycle()-begin;
        printf ("TE_bikj_F %d %d %8.3f \n",n, bsize, (double) benchtime/(n*n*n));
    }
    printf ("\n");    
}
// -----------------------------------------
main_old()
// -----------------------------------------
{
    /*
     main_PS_F();
     main_PS_I(); 
     main_MM_ijk_F();
     main_MM_ikj_F();
     main_MM_ijk_I();
     main_MM_ikj_I();
     */
    
} 
// ------------------------------------
void main_multiplication_routine(int n)
// ------------------------------------
{
    sint32 *BI, *CI;
    float32 *BF, *CF;
    
    sint32  **AI, **XI, **YI;
    float32 **AF, **XF, **YF;
    
    puts("-------------------");
    printf("main_multiplication: n = %4d\n", n);
    puts("-------------------");
    
    // allocation
    BI = si32vector(0, n-1);
    CI = si32vector(0, n-1);
    
    BF = f32vector(0, n-1);
    CF = f32vector(0, n-1);
    
    AI = si32matrix(0, n-1, 0, n-1);
    XI = si32matrix(0, n-1, 0, n-1);
    YI = si32matrix(0, n-1, 0, n-1);
    
    AF = f32matrix(0, n-1, 0, n-1);
    XF = f32matrix(0, n-1, 0, n-1);
    YF = f32matrix(0, n-1, 0, n-1);
    
    // chrono
    main_PS_F(BF, CF, n);
    main_PS_I(BI, CI, n); 
    
    //main_MM_ijk_I(AI, XI, YI, n);
    main_MM_ijk_F(AF, XF, YF, n);
    
    //main_MM_ikj_I(AI, XI, YI, n);
    main_MM_ikj_F(AF, XF, YF, n);
    
    main_MM_bijk_F(AF, XF, YF, n, 10);
    main_MM_bijk_F(AF, XF, YF, n, 20);
    
     main_MM_bijk_F(AF, XF, YF, n, 32);
    
    // free
    free_si32vector(BI, 0, n-1);
    free_si32vector(CI, 0, n-1);
    
    free_f32vector(BF, 0, n-1);
    free_f32vector(CF, 0, n-1);
    
    free_si32matrix(AI, 0, n-1, 0, n-1);
    free_si32matrix(XI, 0, n-1, 0, n-1);
    free_si32matrix(YI, 0, n-1, 0, n-1);
    
    free_f32matrix(AF, 0, n-1, 0, n-1);
    free_f32matrix(XF, 0, n-1, 0, n-1);
    free_f32matrix(YF, 0, n-1, 0, n-1);
} 
// --------------------------------------------
int main_multiplication(int argc, char* argv[])
// --------------------------------------------
{
    // tester differentes valeurs de parametre
    main_multiplication_routine(100);
    return 0;
}
/*
// -----------------------------
int main(int argc, char* argv[])
// -----------------------------
{
    return main_multiplication(argc, argv);
} 
*/









