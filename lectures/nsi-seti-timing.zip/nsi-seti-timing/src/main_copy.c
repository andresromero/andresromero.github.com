// ------------------- //
// --- main_copy.c --- //
// ------------------- //

// Copyright (c) Daniel Etiemble, LRI, Univ Paris-Sud www.lri.fr/~de
// Copyright (c)  Lionel Lacassagne, LRI, Univ Paris-Sud www.lri.fr/~lacas

#include <stdio.h>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <mmintrin.h>

#include "def.h" // typage fort des types de base du C
#include "nrutil.h" // allocation
#include "dcycle.h" // chrono
#include "main_timing.h" // LOOP

// ----------------------------------------------
void main_copy_ij(uint32 **X, uint32 **Y, int n)
// ---------------------------------------------
{
	int i, j, k;
    double starttime, benchtime;
    
	for (k=0;k<LOOP;k++){
        
        starttime=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime=dcycle()-starttime ; 
        printf ("Temps copie par element_ij %8.3f  n= %d \n", (double) (benchtime)/(double)(n*n), n);
        
	}
	printf("\n");
}
// ---------------------------------------------
void main_copy_ji(uint32 **X, uint32 **Y, int n)
// ---------------------------------------------
{
	int i, j, k;
    double starttime, benchtime;
    
	for (k=0;k<LOOP;k++){
        
        starttime=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime=dcycle()-starttime ; 
        printf ("Temps copie par element_ji %8.3f  n %d \n", (double) (benchtime)/(double)(n*n), n);
        
	}
    printf("\n");
}
// ---------------------------------------------
void main_copy_byte(uint8 **X, uint8 **Y, int n)
// ---------------------------------------------
{
	int i, j, k;
    double starttime, benchtime;
    
	for (k=0;k<LOOP;k++){
        
        starttime=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime=dcycle()-starttime ; 
        printf ("Temps copie par element_byte %8.3f  n %d \n", (double) (benchtime)/(double)(n*n), n);
        
	}
	printf("\n");
}

// --------------------------------------------------
void main_copy_float(float32 **X, float32 **Y, int n)
// --------------------------------------------------
{
	int i, j, k;
    double starttime, benchtime;
    
	for (k=0;k<LOOP;k++){
        
        starttime=dcycle();
        
        // AJOUTER CODE ICI
        
        benchtime=dcycle()-starttime ; 
        printf ("Temps copie par element_float %8.3f  n %d \n", (double) (benchtime)/(double)(n*n), n);
        
	}
	printf("\n");
}

// --------------------------
void main_copy_routine(int n)
// --------------------------
{
    uint32 **XI, **YI;
    float32 **XF, **YF;
    uint8 **XB, **YB;
 
    puts("-------------------");
    printf("main_copy: n = %4d\n", n);
    puts("-------------------");
    
    // allocation
    XI = ui32matrix(0, n-1, 0, n-1);
    YI = ui32matrix(0, n-1, 0, n-1);
    
    XB = ui8matrix(0, n-1, 0, n-1);
    YB = ui8matrix(0, n-1, 0, n-1);
    
    XF = f32matrix(0, n-1, 0, n-1);
    YF = f32matrix(0, n-1, 0, n-1);
    
    // chrono
    main_copy_ij(XI, YI, n);
    main_copy_ji(XI, YI, n);
    
    main_copy_byte(XB, YB, n);
    main_copy_float(XF, YF, n);
    
    // free
    free_ui32matrix(XI, 0, n-1, 0, n-1);
    free_ui32matrix(YI, 0, n-1, 0, n-1);
    
    free_ui8matrix(XB, 0, n-1, 0, n-1);
    free_ui8matrix(YB, 0, n-1, 0, n-1);
    
    free_f32matrix(XF, 0, n-1, 0, n-1);
    free_f32matrix(YF, 0, n-1, 0, n-1);
} 
// ----------------------------------
int main_copy(int argc, char* argv[])
// ----------------------------------
{
    // tester differentes valeur de parametre
    main_copy_routine(1000);
    return 0;
}

