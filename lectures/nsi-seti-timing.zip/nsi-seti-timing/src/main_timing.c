// --------------------- //
// --- main_timing.c --- //
// --------------------- //

#include <stdio.h>
#include <stdlib.h>

#include "main_copy.h"
#include "main_multiplication.h"

// -----------------------------
int main(int argc, char* argv[])
// -----------------------------
{
    puts("[main_timing]: start");
    
    puts("[main_timing]: decommenter la ligne suivante pour activer main_copy");
    main_copy(argc, argv);
    
    puts("[main_timing]: decommenter la ligne suivante pour activer main_multiplication");
    //main_multiplication(argc, argv);
    
    puts("[main_timing]: bye");
}
