/* ----------------------- */
/* --- test_motionNR.c --- */
/* ----------------------- */

/*
 * Copyright (c) 2011-2012 Lionel Lacassagne, all rights reserved
 * University Paris Sud 11
 */

#ifndef __TEST_MOTION_NR_H__
#define __TEST_MOTION_NR_H__

#ifdef __cplusplus
extern "C" {
#endif
    
int test_motionNR(int argc, const char *argv[]);

#ifdef __cplusplus
}
#endif

#endif // __TEST_MOTION_NR_H__